backend=uma
model_name=uma-s-1p1
task_name=omol
charge=0
spin=1
